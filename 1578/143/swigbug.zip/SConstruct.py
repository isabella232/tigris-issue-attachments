import SCons.Scanner
import os
import os.path

os.environ['PATH'] += ';c:\\dcsdk\\dependencies\\bin\\win32\\SWIG_debug'

env = Environment(ENV = os.environ)

env.Append( CPPPATH = os.path.abspath(os.curdir) )

env.CXXFile( 'wrapper.cpp', 'master.i' )

env.SharedLibrary( 'wrapper.cpp' )
