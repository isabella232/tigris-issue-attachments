/* includee2.h content */

class SomeClass2
{
};

/* end includee2.h content */
