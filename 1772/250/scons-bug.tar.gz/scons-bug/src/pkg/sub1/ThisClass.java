package pkg.sub1;

import pkg.sub2.ThatClass;

public class ThisClass {
	// ...
}

