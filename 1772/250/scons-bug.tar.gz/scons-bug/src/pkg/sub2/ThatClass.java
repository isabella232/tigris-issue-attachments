package pkg.sub2;

public class ThatClass {
	// ...
}

