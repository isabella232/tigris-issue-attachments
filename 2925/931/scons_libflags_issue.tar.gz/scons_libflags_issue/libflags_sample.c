#include <stdio.h>
#include "libtelnet.h"

int main(int argc, char* argv[])
{
        telnet_init(0, 0, '\x0', 0);
        return 0;
}
