#!/bin/bash

# This script should return non-zero error code when test fails
rm /tmp/foo
gcc -o /tmp/foo test.c
/tmp/foo | grep "lolcat:" > /dev/null
status=$?
if [ $status -eq 0 ];
then
	exit 1
else
	exit 0
fi;

