#!/usr/bin/env python
# -*- Python -*-

from optparse import OptionParser
import subprocess
import sys

def error(s):
    print >>sys.stderr, "**********************************", s, "**********************************"
    sys.exit(1)    

def logic_bug():
    error("Oops... Logic bug. Hehe")    

def updaterevisions(lower,upper):
    print "************** %s revisions to test (bug bracketed by [%s,%s])" % (int((upper-lower+1)/2),lower,upper)

def call(script_and_args):
    return subprocess.call(script_and_args,shell=False)

def svnup(revision):
    print "Updating to revision %s" % revision
    if subprocess.call(["svn","up","-r",str(revision)]) != 0:
        raise RuntimeError, "SVN did not update properly to revision %s" % revision

def testfail(revision,script_and_args):
    "Return true if test fails"
    svnup(revision)
    return call(script_and_args) != 0

parser = OptionParser(usage="%prog [options] lower-revision upper-revision test_script arg1 arg2",
                      description="Binary search for a bug in a SVN checkout")

(options,script_args) = parser.parse_args()

if len(script_args) < 1:
    parser.error("Need a lower revision!")
elif len(script_args) < 2:
    parser.error("Need an upper revision!")
elif len(script_args) < 3:
    parser.error("Need a script to run!")

lower = int(script_args[0])
upper = int(script_args[1])
script = script_args[2:]

updaterevisions(lower,upper)

lowerfails = testfail(lower,script)
upperfails = testfail(upper,script)
if lowerfails == upperfails:
    error("Both upper and lower revisions failed! Upper and lower revisions must bracket the failure!")

while upper-lower > 1:
    updaterevisions(lower,upper)

    mid = int((lower + upper)/2)
    midfails = testfail(mid,script)
    if midfails == lowerfails:
        lower = mid
        lowerfails = midfails
    elif midfails == upperfails:
        upper = mid
        upperfails = midfails

    if lowerfails == upperfails:
        logic_bug()

if upperfails:
    print "The error was caused by change %s" % upper
elif lowerfails:
    print "The error was caused by change %s" % lower
else:
    logic_bug()
