#include <iostream>

int main(int argc, char** argv) {
    std::cout << "T0" << std::endl;
    return 0;
}
