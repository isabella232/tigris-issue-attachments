#include <iostream>

int main(int argc, char** argv) {
    std::cout << "T1" << std::endl;
    return 0;
}
