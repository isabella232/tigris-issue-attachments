#include <iostream>
using std::cout;
using std::endl;

int main(void)
{
  cout << "Hello world!" << endl;

  return 0;
}

