#ifndef A
#define A

void a();

#endif
