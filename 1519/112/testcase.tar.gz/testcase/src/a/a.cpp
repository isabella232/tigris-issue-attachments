#include <iostream>
#include <a/a.h>

void a()
{
    std::cout << "a()" << std::endl;
}
