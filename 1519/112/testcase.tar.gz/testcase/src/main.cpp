#include <a/a.h>

int main()
{
    a();

    return 0;
}
