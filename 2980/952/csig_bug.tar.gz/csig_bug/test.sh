#!/bin/bash
if [ "$1" == "" ]; then
  echo "Usage: $0 /path/to/sconsdir"
  exit 2
fi
SCONSDIR=$1
cd repo/
git checkout 6ee27c0db68515e3faa71bf25c0ed7a883ecf697
git clean -fdx
${SCONSDIR}/scons.py
git checkout master
${SCONSDIR}/scons.py
${SCONSDIR}/sconsign.py -c .sconsign.dblite
md5sum alpha.h
md5sum beta.h
md5sum gamma.h
md5sum main.cpp

