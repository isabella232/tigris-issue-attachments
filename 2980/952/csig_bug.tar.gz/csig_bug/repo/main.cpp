
#include "alpha.h"
#include "beta.h"
#include "gamma.h"

int main()
{
    return 0;
}

