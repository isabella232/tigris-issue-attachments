
#ifndef GAMMA_H
#define GAMMA_H

#endif

