#include <Python.h>
#include <string>
#include <algorithm>
#include <iostream>
#include <map>
#include <cstdlib>

#define MEMO "_MeMoIZeR"
#define MEMOKEY "_MeMoIZeR_Key"

static bool dump_stats_on_destruction = false;
static char os_sep;

typedef struct {
  unsigned int hits;
  unsigned int misses;
} StatCount_t;

struct print_individual_map {
  print_individual_map(const char* prefix) : prefix_(prefix) {}
  void operator()(const std::pair<const char*,StatCount_t>& stat) {
    std::fprintf(stderr,"%7d hits\t%7d misses %s.%s()\n",stat.second.hits,
		 stat.second.misses,prefix_,stat.first);
  }
  const char* prefix_;
};

struct print_statmap {
  print_statmap() {
    std::cerr << "Memoizer (memory cache) hits and misses" << std::endl;
  }
  void operator()(const std::pair< const char*,
		  std::map< const char*, StatCount_t > >& class_stat) {
    std::for_each(class_stat.second.begin(),
		  class_stat.second.end(),
		  print_individual_map(class_stat.first));
  }
};

/*
  pedantry might do this as a Singleton. . .*shrug*

  It's a map of maps where the first key is the class name and the key for the
  second map is the method name.

  This allows reuse of Python's already interned strings.

  Algorithmically: using a map oughta be reasonably efficient
*/

struct CacheStats {
  CacheStats() {}
  ~CacheStats() {
    if(dump_stats_on_destruction)
      std::for_each(stat_map.begin(),stat_map.end(),print_statmap());
  }
  void hit(char* classname, char* methname) {
    stat_map[classname][methname].hits++;
  }
  void miss(char* classname, char* methname) {
    stat_map[classname][methname].misses++;
  }
  std::map< const char*, std::map< const char*, StatCount_t > > stat_map;
} cache_count;

/*
  a simple wrapper class used to ensure PyObjects have their
  refcnt dropped.  Useful in two situations:
     o temporary objects
     o ensuring refcnts are dropped when we're out of memory
*/
struct UnwindPyObject {
  UnwindPyObject(PyObject* obj,bool decref_needed = true) : obj_(obj),decref_needed_(decref_needed) {
    if(obj_ == 0)throw std::bad_alloc();
  }
  ~UnwindPyObject() {
    if(obj_ != 0 && decref_needed_)Py_DECREF(obj_);
  }
  PyObject* obj_;
  bool decref_needed_;
};

struct ArgHandler {
  ArgHandler(PyObject *self, PyObject *args) : self_(self),args_(args) {}
  virtual bool arg_predicate(void)=0;
  virtual PyObject* do_arg_operation(void)=0;
  PyObject* operator()(const char* arg_exception_text) {
    if(arg_predicate() == false) {
      PyErr_SetString(PyExc_RuntimeError,arg_exception_text);
      return(0);
    }

    try {
      return(do_arg_operation());
    } catch(std::bad_alloc) {
      PyErr_SetString(PyExc_RuntimeError,"oom exception in the memoizer");
      return(0);
    }
  }

  /*
    lookup a cache value
    if it's not there --> call the object and store the result in cache

    Currently, all operations do cache count operations regardless of 
    the value of the module's dump_stats_on_destruction setting.  It's
    likely the largest gain from this would come from avoiding the two
    calls in PyObject_GetAttrString used to determine class_name.
  */
  PyObject *exec_python_fn(std::string& ckey,PyObject* funargs,
			   PyObject* kw,PyObject* prefix_obj) {
    char* ckey_ = const_cast<char*>(ckey.c_str());
    PyObject* value = PyMapping_GetItemString(cdict,ckey_);
    char*  class_name = PyString_AS_STRING(UnwindPyObject(PyObject_GetAttrString(UnwindPyObject(PyObject_GetAttrString(prefix_obj,"__class__")).obj_,"__name__")).obj_);
    
    if(value != 0) {
      cache_count.hit(class_name,PyString_AS_STRING(methname_));
      return(value);
    }

    PyErr_Clear();
    cache_count.miss(class_name,PyString_AS_STRING(methname_));
    if((value = PyObject_Call(func,funargs,kw)) == 0)
      PyErr_SetString(PyExc_RuntimeError,"Failed appying function");
    else 
      PyMapping_SetItemString(cdict,ckey_,value);
    
    return(value);
  }
  
  PyObject* methname_;
  PyObject* self_;
  PyObject* args_;
  PyObject *cdict;
  PyObject *func;
};

static PyObject *
memoize_cache_get(PyObject *self, PyObject *args) {
  struct MemoizeCacheGet : ArgHandler {
    MemoizeCacheGet(PyObject* self, PyObject* args) : ArgHandler(self,args) {}
    bool arg_predicate(void) {
      return(PyArg_ParseTuple(args_,"OOOOO",&methname_,&func,&cdict,
			      &argtuple,&kw) && 
	     PyString_Check(methname_) && PyCallable_Check(func) && 
	     PyDict_Check(cdict) && PyTuple_Check(argtuple) && PyDict_Check(kw));
    }

    PyObject *do_arg_operation(void) {
      PyObject* object0 = PyTuple_GET_ITEM(argtuple,0);
      std::string ckey(PyString_AsString(UnwindPyObject(PyObject_GetAttrString(object0,MEMOKEY)).obj_));
      ckey = ckey + ':' + PyString_AS_STRING((UnwindPyObject(build_key(argtuple,kw)).obj_));
      return(exec_python_fn(ckey,argtuple,kw,object0));
    }
    PyObject* build_key(PyObject *tuple,PyObject *dict) {
      UnwindPyObject items(PyDict_Items(dict));
      std::string key("");
      int i,last;
      PyObject *tmpobj;
      
      for(i = 0, last = PyTuple_GET_SIZE(tuple); i < last; i++) {
	PyObject *workobj = PyTuple_GET_ITEM(tuple,i);
	if((tmpobj = PyObject_GetAttrString(workobj,MEMOKEY)) == 0)
	  tmpobj = PyObject_Repr(workobj);
	
	key = key + PyString_AS_STRING(UnwindPyObject(tmpobj).obj_) + '|';
      }
      
      for(i = 0, last = PyList_GET_SIZE(items.obj_); i < last; i++) {
	PyObject *value_,*attr_,*elt = PyList_GET_ITEM(items.obj_,i);

	key = key + PyString_AS_STRING(UnwindPyObject(PyObject_Str(PyTuple_GET_ITEM(elt,0))).obj_) + '|';

	value_ = PyTuple_GET_ITEM(elt,1);    
	if((attr_ = PyObject_GetAttrString(value_,MEMOKEY)) == 0)
	  attr_ = PyObject_Repr(value_);
	
	key = key + PyString_AS_STRING(UnwindPyObject(attr_).obj_) + '|';
      }

      PyErr_Clear(); // in case a PyObject_Get*String failed earlier
      return(PyString_FromString(key.c_str()));
    }

    PyObject* argtuple;
    PyObject* kw;
  };
  return(MemoizeCacheGet(self,args)("memoize_cache_get takes five arguments(methname,function,dictionary,tuple,dictionary)"));
}

static PyObject *
memoize_cache_get_self(PyObject *self, PyObject *args) { 
  struct MemoizeCacheGetSelf : ArgHandler {
    MemoizeCacheGetSelf(PyObject* self, PyObject* args) : ArgHandler(self,args) {}
    bool arg_predicate(void) {
      return(PyArg_ParseTuple(args_,"OOOO",&methname_,&func,&cdict,&self_) &&
	     PyString_Check(methname_) && PyCallable_Check(func) && 
	     PyDict_Check(cdict));
      // PyInstance_Check(self_) -- a no go
    }
    PyObject* do_arg_operation(void) {
      std::string ckey(PyString_AsString(UnwindPyObject(PyObject_GetAttrString(self_,MEMOKEY)).obj_));
      UnwindPyObject argtuple(PyTuple_New(1));
      PyTuple_SetItem(argtuple.obj_,0,self_);
      Py_INCREF(self_);
      return(exec_python_fn(ckey,argtuple.obj_,0,self_));
    }
    PyObject* self_;
  };

  return(MemoizeCacheGetSelf(self,args)("memoize_cache_get_self takes four arguments(methname,function,dictionary,object)"));
}

static PyObject *
memoize_cache_get_one(PyObject *self, PyObject *args) { 
  struct MemoizeCacheGetOne : ArgHandler {
    MemoizeCacheGetOne(PyObject *self, PyObject* args) : ArgHandler(self,args) {}
    bool arg_predicate(void) {
      return(PyArg_ParseTuple(args_,"OOOOO",&methname_,&func,&cdict,&self_,
			      &onearg) && 
	     PyString_Check(methname_) && PyCallable_Check(func) && 
	     PyDict_Check(cdict));
      // XXX -- PyInstance_Check(self_))
    }
    PyObject* do_arg_operation(void) {
      std::string ckey(PyString_AsString(UnwindPyObject(PyObject_GetAttrString(self_,MEMOKEY)).obj_));
      ckey += ':';
      PyObject *argkey = PyObject_GetAttrString(onearg,MEMOKEY);

      if(argkey == 0)
	PyErr_Clear();

      ckey += PyString_AsString(UnwindPyObject(argkey ? argkey : PyObject_Repr(onearg)).obj_);

      UnwindPyObject argtuple(PyTuple_New(2));
      PyTuple_SetItem(argtuple.obj_,0,self_);
      Py_INCREF(self_);
      PyTuple_SetItem(argtuple.obj_,1,onearg);
      Py_INCREF(onearg);
      return(exec_python_fn(ckey,argtuple.obj_,0,self_));
    }
    PyObject* self_;
    PyObject* onearg;
  };
  return(MemoizeCacheGetOne(self,args)("memoize_cache_get_one takes five arguments(methname,function,dictionary,object,argument)"));;
}

static PyObject*
enable_cache_stat_dump(PyObject*,PyObject*) {
  dump_stats_on_destruction = true;
  Py_INCREF(Py_None);
  return(Py_None);
}

static PyObject*
next_memoizer_key(PyObject*,PyObject*) {
  static long keyval = 0;
  return(PyString_FromFormat("%ld",keyval++));
}

static PyObject*
whoami(PyObject* self, PyObject* args) {
  const char* memo_funcname;
  const char* real_funcname;
  
  if(PyArg_ParseTuple(args,"ss",&memo_funcname,&real_funcname) == 0) {
    PyErr_SetString(PyExc_RuntimeError,"takes two strings as input");
    return(0);
  }

  return(PyString_FromFormat("...%cSCons%cMemoizer-%s-lambda<%s>",os_sep,os_sep,memo_funcname,real_funcname));
}

static PyMethodDef CmoizerMethods[] = {
  {"memoize_cache_get", memoize_cache_get, METH_VARARGS, "memoize_cache_get(func,cdict,args,kw) -- lookup a memoized value for an object -- if not yet memoized, apply(func,args,kw), stuff the result into cdict and return result"},
  {"memoize_cache_get_self", memoize_cache_get_self, METH_VARARGS, "memoize_cache_get_self(func,cdict,self) -- lookup a memoized value for an object -- if not yet memoized, result = func(self), stuff the result into cdict and return result"},
  {"memoize_cache_get_one", memoize_cache_get_one, METH_VARARGS, "memoize_cache_get_one(func,cdict,one) -- lookup a memoized value for an object -- if not yet memoized, result = func(self,arg), stuff the result into cdict and return result"},
  {"enable_cache_stat_dump", enable_cache_stat_dump, METH_VARARGS, "enable_cache_stat_dump() --> defaults to false and can only be turned on -- return None" },
  {"next_memoizer_key", next_memoizer_key, METH_VARARGS, "next_memoizer_key() --> string representation of a monotomically increasing integer" },
  {"whoami", whoami, METH_VARARGS, "whoami(memoizer_funcname,real_funcname) --> string containing memoized name"},
  {NULL,NULL,0,NULL}
};

PyMODINIT_FUNC
initCmoizer(void) {
  // XXX -- not paranoid enough?
  UnwindPyObject osmodule(PyImport_ImportModule("os"));
  UnwindPyObject sep(PyObject_GetAttrString(osmodule.obj_,"sep"));
  os_sep = *(PyString_AS_STRING(sep.obj_));
  (void) Py_InitModule("Cmoizer",CmoizerMethods);
}
