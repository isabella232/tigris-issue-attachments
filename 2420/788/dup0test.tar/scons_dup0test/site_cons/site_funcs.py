# This is standard Python code.
#
# -*- coding: utf-8 -*-

import optparse
import cStringIO
import os
import os.path
import re
import subprocess
import sys

# import scons definitions (Builder, Append etc.)
from SCons.Script import *

def weave_latex_builder(env):
    weave_latex = Builder(action='cp $SOURCE $TARGET',
            suffix='.tex',
            src_suffix='.nw')
    env.Append( BUILDERS={'WeaveLatex' : weave_latex} )


