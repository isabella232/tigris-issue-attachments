#ifndef FUNC_A_H_
#define FUNC_A_H_
#ifdef WIN32
#  ifdef DLL_library_1_EXPORTS
#     define LIBRARY_1_SHARED_API __declspec(dllexport)
#  else
#     define LIBRARY_1_SHARED_API __declspec(dllimport)
#  endif
#else
#  define LIBRARY_1_SHARED_API
#endif

LIBRARY_1_SHARED_API int func_a();

#endif /* FUNC_A_H_ */