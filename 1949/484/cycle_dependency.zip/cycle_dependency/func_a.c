#include "func_a.h"
#include "func_c.h"

int func_a()
{
   return func_c()-1;
}
