#include "func_b.h"

int func_b()
{
   return 0;
}
