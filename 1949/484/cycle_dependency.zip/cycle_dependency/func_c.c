#include "func_c.h"
#include "func_a.h"

int func_c()
{
   return func_b() + 1;
}
