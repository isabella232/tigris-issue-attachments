#ifndef FUNC_C_H_
#define FUNC_C_H_
#ifdef WIN32
#  ifdef DLL_library_2_EXPORTS
#     define LIBRARY_2_SHARED_API __declspec(dllexport)
#  else
#     define LIBRARY_2_SHARED_API __declspec(dllimport)
#  endif
#else
#  define LIBRARY_2_SHARED_API
#endif

LIBRARY_2_SHARED_API int func_c();

#endif /* FUNC_C_H_ */