f=open('file.txt','b')
f.write('fff')
f.close()

