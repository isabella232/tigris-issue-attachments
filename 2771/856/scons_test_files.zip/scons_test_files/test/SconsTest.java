package test;

import java.util.HashSet;

public class SconsTest{
    
//////VARIETY 1////////

	public static void main(String[] args){
		new Object(){
			{
				new Object(){};
			}
		};
	}

///////////////////////

//////VARIETY 2//////
/*
	public static void main(String[] args){
	}

	public static class Test{
		public Test(){
			new Object(){};
		}
	}
*/
/////////////////////

}
