#include <stdio.h>

extern int blorg();
int main() {
    printf("Hello\n");
    blorg();
}
