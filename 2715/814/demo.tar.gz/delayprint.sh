#!/bin/sh

echo $1 beg
sleep $1
echo $1 mid
sleep $1
echo $1 end
