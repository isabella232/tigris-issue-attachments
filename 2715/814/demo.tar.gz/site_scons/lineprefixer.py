class LinePrefixerFile:
    def __init__(self, backing, prefix):
        self.__backing = backing
        self.__at_start = True
        self.__prefix = prefix

    def close(self):
        self.__backing.close()

    def flush(self):
        self.__backing.flush()

    def writelines(self, seq):
        for item in seq:
            self.wirte(item)

    def write(self, item):
        item = str(item)
        lines = item.split('\n')

        # write out the first line
        if self.__at_start:
            self.__backing.write(self.__prefix)

        # Check to see whether we ended with a blank line (in which case we
        # don't want to write out the prefix yet but will do it next time
        # around)
        if len(lines) > 0 and lines[-1] == '':
            self.__at_start = True
            lines = lines[:-1]
        else:
            self.__at_start = False

        # Now print out all the other lines
        self.__backing.write(('\n'+self.__prefix).join(lines))

        # One more step: if the last character of the input was a newline, we
        # haven't printed it yet (because we don't want to print the
        # prefix). But we still need that newline
        if self.__at_start:
            self.__backing.write('\n')

    def set_prefix(self, prefix):
        self.__prefix = prefix
