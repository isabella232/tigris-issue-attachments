
                #include <iostream>

                void hello26()
                {
                    std::cout << "hello from 26\n";
                }
                