"""
Generate a bunch of .cpp files to demo scons verbose output.
"""

if __name__ == "__main__":

    hello_hpp_code = ""

    for count in xrange(200):

        hello_hpp_code += """
            void hello{id_}();
            """.format(id_ = count);

        # Write out .cpp file
        with open("hello%03d.cpp" % count, "w") as fd:

            fd.write(r"""
                #include <iostream>

                void hello{id_}()
                {{
                    std::cout << "hello from {id_}\n";
                }}
                """.format(id_ = count))

    # Write out .hpp file
    with open("hello.hpp", "w") as fd:
        fd.write(hello_hpp_code)

