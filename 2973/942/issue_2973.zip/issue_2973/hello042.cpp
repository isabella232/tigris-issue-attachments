
                #include <iostream>

                void hello42()
                {
                    std::cout << "hello from 42\n";
                }
                