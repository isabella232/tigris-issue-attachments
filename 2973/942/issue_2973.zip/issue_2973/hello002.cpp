
                #include <iostream>

                void hello2()
                {
                    std::cout << "hello from 2\n";
                }
                