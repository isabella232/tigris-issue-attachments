
                #include <iostream>

                void hello64()
                {
                    std::cout << "hello from 64\n";
                }
                