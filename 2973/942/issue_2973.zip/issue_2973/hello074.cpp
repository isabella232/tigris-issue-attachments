
                #include <iostream>

                void hello74()
                {
                    std::cout << "hello from 74\n";
                }
                