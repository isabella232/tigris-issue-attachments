
                #include <iostream>

                void hello151()
                {
                    std::cout << "hello from 151\n";
                }
                