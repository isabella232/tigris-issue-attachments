
                #include <iostream>

                void hello40()
                {
                    std::cout << "hello from 40\n";
                }
                