
                #include <iostream>

                void hello186()
                {
                    std::cout << "hello from 186\n";
                }
                