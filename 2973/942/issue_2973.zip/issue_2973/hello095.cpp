
                #include <iostream>

                void hello95()
                {
                    std::cout << "hello from 95\n";
                }
                