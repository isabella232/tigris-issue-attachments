
                #include <iostream>

                void hello52()
                {
                    std::cout << "hello from 52\n";
                }
                