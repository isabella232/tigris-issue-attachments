
                #include <iostream>

                void hello78()
                {
                    std::cout << "hello from 78\n";
                }
                