
                #include <iostream>

                void hello1()
                {
                    std::cout << "hello from 1\n";
                }
                