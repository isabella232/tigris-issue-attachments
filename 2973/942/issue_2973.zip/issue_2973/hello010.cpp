
                #include <iostream>

                void hello10()
                {
                    std::cout << "hello from 10\n";
                }
                