
                #include <iostream>

                void hello5()
                {
                    std::cout << "hello from 5\n";
                }
                