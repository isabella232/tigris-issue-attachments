
                #include <iostream>

                void hello38()
                {
                    std::cout << "hello from 38\n";
                }
                