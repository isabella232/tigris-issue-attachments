
                #include <iostream>

                void hello6()
                {
                    std::cout << "hello from 6\n";
                }
                