
                #include <iostream>

                void hello100()
                {
                    std::cout << "hello from 100\n";
                }
                