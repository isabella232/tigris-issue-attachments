#include "hello.hpp"

int main(void)
{
    return 0;
}
