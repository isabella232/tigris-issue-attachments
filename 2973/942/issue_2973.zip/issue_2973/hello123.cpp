
                #include <iostream>

                void hello123()
                {
                    std::cout << "hello from 123\n";
                }
                