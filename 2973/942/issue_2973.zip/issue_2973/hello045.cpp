
                #include <iostream>

                void hello45()
                {
                    std::cout << "hello from 45\n";
                }
                