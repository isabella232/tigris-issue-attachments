
                #include <iostream>

                void hello99()
                {
                    std::cout << "hello from 99\n";
                }
                