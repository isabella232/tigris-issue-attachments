
                #include <iostream>

                void hello8()
                {
                    std::cout << "hello from 8\n";
                }
                