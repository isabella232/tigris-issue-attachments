
                #include <iostream>

                void hello24()
                {
                    std::cout << "hello from 24\n";
                }
                