
                #include <iostream>

                void hello49()
                {
                    std::cout << "hello from 49\n";
                }
                