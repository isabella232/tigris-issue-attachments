
                #include <iostream>

                void hello27()
                {
                    std::cout << "hello from 27\n";
                }
                