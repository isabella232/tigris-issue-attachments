
                #include <iostream>

                void hello9()
                {
                    std::cout << "hello from 9\n";
                }
                