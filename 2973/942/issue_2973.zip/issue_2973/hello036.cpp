
                #include <iostream>

                void hello36()
                {
                    std::cout << "hello from 36\n";
                }
                