
                #include <iostream>

                void hello56()
                {
                    std::cout << "hello from 56\n";
                }
                