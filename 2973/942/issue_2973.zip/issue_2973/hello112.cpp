
                #include <iostream>

                void hello112()
                {
                    std::cout << "hello from 112\n";
                }
                