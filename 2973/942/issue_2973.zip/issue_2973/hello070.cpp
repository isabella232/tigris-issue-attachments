
                #include <iostream>

                void hello70()
                {
                    std::cout << "hello from 70\n";
                }
                