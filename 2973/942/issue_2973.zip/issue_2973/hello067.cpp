
                #include <iostream>

                void hello67()
                {
                    std::cout << "hello from 67\n";
                }
                