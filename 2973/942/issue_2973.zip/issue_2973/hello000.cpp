
                #include <iostream>

                void hello0()
                {
                    std::cout << "hello from 0\n";
                }
                