
                #include <iostream>

                void hello4()
                {
                    std::cout << "hello from 4\n";
                }
                