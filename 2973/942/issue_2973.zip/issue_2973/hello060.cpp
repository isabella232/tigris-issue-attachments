
                #include <iostream>

                void hello60()
                {
                    std::cout << "hello from 60\n";
                }
                