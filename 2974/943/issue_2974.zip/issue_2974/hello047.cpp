
                #include <iostream>

                void hello47()
                {
                    std::cout << "hello from 47\n";
                }
                