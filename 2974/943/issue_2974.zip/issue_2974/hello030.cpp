
                #include <iostream>

                void hello30()
                {
                    std::cout << "hello from 30\n";
                }
                