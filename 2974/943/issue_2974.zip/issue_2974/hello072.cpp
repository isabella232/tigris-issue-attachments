
                #include <iostream>

                void hello72()
                {
                    std::cout << "hello from 72\n";
                }
                