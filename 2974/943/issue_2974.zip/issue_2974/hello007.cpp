
                #include <iostream>

                void hello7()
                {
                    std::cout << "hello from 7\n";
                }
                