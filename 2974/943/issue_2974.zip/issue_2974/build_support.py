"""

Grabbed some code off the internet to filter builder output, I tired to
simplify it.

Reference:
    http://nuitka.net/gitweb/?p=Nuitka.git;a=blob;f=nuitka/build/SingleExe.scons;h=0707b76bb4c51f6a0c3c528b311c8d4e80acda32;hb=HEAD

"""

import os
import subprocess

def setup_spawn( env , verbose = False):

    def spawn( sh, escape, cmd, args, env ):

        cmd = args[0]

        cmdline = ' '.join([str(x) for x in args])

        startupinfo = subprocess.STARTUPINFO()

        # CPython2.6 compatibility
        try:
            from subprocess import STARTF_USESHOWWINDOW
        except ImportError:
            from _subprocess import STARTF_USESHOWWINDOW

        startupinfo.dwFlags |= STARTF_USESHOWWINDOW

        proc = subprocess.Popen(
            cmdline,
            stdin       = subprocess.PIPE,
            stdout      = subprocess.PIPE,
            stderr      = subprocess.PIPE,
            startupinfo = startupinfo,
            shell       = False,
            env         = env
        )

        data, err = proc.communicate()
        rv = proc.wait()

        if cmd == "cl":
            data = data[ data.find( "\r\n" ) + 2 : ]

        elif cmd == "link":

#~            print ""
#~            print "cmdline =", cmdline
#~            print ""

            data = "\r\n".join(
                line
                for line in
                data.split( "\r\n" )
                if "   Creating library" not in line
            )

        if data.rstrip():
#~            if not show_scons_mode:
#~                print cmdline
            print data,

        if rv:
            raise RuntimeError( err )

        return rv

    if not verbose:
        env[ "SPAWN" ] = spawn

