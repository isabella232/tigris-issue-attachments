
                #include <iostream>

                void hello106()
                {
                    std::cout << "hello from 106\n";
                }
                