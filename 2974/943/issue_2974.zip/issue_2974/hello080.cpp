
                #include <iostream>

                void hello80()
                {
                    std::cout << "hello from 80\n";
                }
                