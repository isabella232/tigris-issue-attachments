
                #include <iostream>

                void hello101()
                {
                    std::cout << "hello from 101\n";
                }
                