
                #include <iostream>

                void hello96()
                {
                    std::cout << "hello from 96\n";
                }
                