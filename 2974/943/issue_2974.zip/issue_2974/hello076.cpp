
                #include <iostream>

                void hello76()
                {
                    std::cout << "hello from 76\n";
                }
                