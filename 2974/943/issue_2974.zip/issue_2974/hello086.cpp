
                #include <iostream>

                void hello86()
                {
                    std::cout << "hello from 86\n";
                }
                