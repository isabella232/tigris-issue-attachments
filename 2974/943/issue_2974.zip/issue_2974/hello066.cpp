
                #include <iostream>

                void hello66()
                {
                    std::cout << "hello from 66\n";
                }
                