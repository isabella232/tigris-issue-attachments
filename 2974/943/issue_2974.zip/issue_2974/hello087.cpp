
                #include <iostream>

                void hello87()
                {
                    std::cout << "hello from 87\n";
                }
                