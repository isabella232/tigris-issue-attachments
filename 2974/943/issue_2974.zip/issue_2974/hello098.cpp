
                #include <iostream>

                void hello98()
                {
                    std::cout << "hello from 98\n";
                }
                