
                #include <iostream>

                void hello18()
                {
                    std::cout << "hello from 18\n";
                }
                