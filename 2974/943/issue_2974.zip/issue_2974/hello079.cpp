
                #include <iostream>

                void hello79()
                {
                    std::cout << "hello from 79\n";
                }
                