
                #include <iostream>

                void hello3()
                {
                    std::cout << "hello from 3\n";
                }
                