
                #include <iostream>

                void hello187()
                {
                    std::cout << "hello from 187\n";
                }
                