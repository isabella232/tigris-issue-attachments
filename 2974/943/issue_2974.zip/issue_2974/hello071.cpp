
                #include <iostream>

                void hello71()
                {
                    std::cout << "hello from 71\n";
                }
                