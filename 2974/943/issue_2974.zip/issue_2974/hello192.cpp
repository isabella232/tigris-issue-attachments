
                #include <iostream>

                void hello192()
                {
                    std::cout << "hello from 192\n";
                }
                