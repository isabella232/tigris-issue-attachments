
                #include <iostream>

                void hello51()
                {
                    std::cout << "hello from 51\n";
                }
                