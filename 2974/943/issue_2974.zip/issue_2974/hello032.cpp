
                #include <iostream>

                void hello32()
                {
                    std::cout << "hello from 32\n";
                }
                