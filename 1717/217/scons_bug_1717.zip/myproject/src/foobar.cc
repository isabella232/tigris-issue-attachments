int
foobar()
{
	return 0;
}