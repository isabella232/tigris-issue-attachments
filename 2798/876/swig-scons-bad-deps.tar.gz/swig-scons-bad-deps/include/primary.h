#ifndef PRIMARY_H
#define PRIMARY_H

#include "secondary.h"

int returnZero();

#endif // PRIMARY_H
