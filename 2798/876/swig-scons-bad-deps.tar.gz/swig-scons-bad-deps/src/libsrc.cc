#include "primary.h"

int returnZero() { return 0; }
