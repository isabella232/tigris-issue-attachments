#ifndef SECONDARY_H
#define SECONDARY_H

void doNothing() {}

#endif // SECONDARY_H
