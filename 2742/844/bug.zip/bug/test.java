class test
{
    test()
    {
        super();
        new inner();
    }

    private static class inner
    {
        private inner() {}
    }
}
