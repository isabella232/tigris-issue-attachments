#ifndef MYLIB2_H
#define MYLIB2_H

#include <iostream>
#include "mylib2.h"

using namespace std;

void myLib2();

#endif
