#include "mylib2.h"

void myLib2() {
  cout << "myLib2 local called" << endl;
}
