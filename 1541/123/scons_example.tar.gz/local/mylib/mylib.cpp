#ifndef MYLIB_CPP
#define MYLIB_CPP

#include "mylib.h"

void myPrint() {
  cout << "Repository VI non-template myPrint() called." << endl;
  myLib1();
}

template <typename T>
MyClass<T>::MyClass(T inValue) {
  myValue = inValue;
}

template <typename T>
void MyClass<T>::print() {
  cout << "Repository VI template MyClass::print called: " << myValue << endl;
  myLib1();
}

template <typename T>
T MyClass<T>::returnValue() {
  return myValue;
}

#endif
