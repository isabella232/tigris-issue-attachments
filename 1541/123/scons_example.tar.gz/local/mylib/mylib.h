#ifndef MYLIB_H
#define MYLIB_H

#include <iostream>
#include "mylib1.h"

using namespace std;

void myPrint();

template <typename T>
class MyClass {
public:
  MyClass(T inValue);
  void print();
  T returnValue();
private:
  T myValue;
};

#include "mylib.cpp"

#endif
