#include "mylib1.h"

void myLib1() {
  cout << "myLib1 repository called" << endl;
  myLib2();
}
