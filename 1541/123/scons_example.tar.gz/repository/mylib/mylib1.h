#ifndef MYLIB1_H
#define MYLIB1_H

#include <iostream>
#include "mylib2.h"

using namespace std;

void myLib1();

#endif
