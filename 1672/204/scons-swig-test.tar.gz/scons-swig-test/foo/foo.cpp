#include "foo.h"

int fooAdd(int a, int b) {
	return a + b;
}