
#define FILE_INCLUDE "file.tpl"

#include "file.inc"
