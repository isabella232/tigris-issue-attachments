

class Vector
{
 public:
  Vector(int size = 0) : _size(size)
  {
    _v = new double[_size];
    for (int i = 0; i < _size; ++i)
      _v[i] = 0.0;
  }

  ~Vector() { delete [] _v; }

  int size() const { return _size; }

  double&        operator[](int key)       { return _v[key]; }
  double  const& operator[](int key) const { return _v[key]; }

 private:
  int _size;
  double* _v;
};
