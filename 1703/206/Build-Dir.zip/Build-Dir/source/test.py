#!/usr/bin/env python
import linalg


x = linalg.Vector(5)
print x

x[1] = 99.5
x[3] = 8.3
x[4] = 11.1


for i, v in enumerate(x):
    print "\tx[%d] = %g" % (i, v)

