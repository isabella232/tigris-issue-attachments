#!/usr/bin/perl
die "Hurray! It's working!" or printf "hello world 3!\n"
