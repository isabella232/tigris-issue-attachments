#include <iostream>
#include "headerOne.h"
#include "headerTwo.h"

int main()
{
	std::cout << "sconsbug" << std::endl;
	return 0;
}