#include "master.h"

int alpha;
