#include "master.h"

int main(int argc, char** argv) {
  Sleep(3000);
}
