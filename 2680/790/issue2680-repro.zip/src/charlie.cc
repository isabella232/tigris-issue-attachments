#include "master.h"

int charlie;
