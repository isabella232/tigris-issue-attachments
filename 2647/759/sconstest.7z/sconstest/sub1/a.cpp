
#include <cstdio>

__declspec(dllexport) void foo()
{
	std::printf("Hello");
}