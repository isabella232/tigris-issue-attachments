
Import('env')

def myscanner(node, env, path):
	print 'Scanning ...'
	#return [ env.File('#/install/dir2/infile2') ]
	return [ env.Dir('#/install/dir2') ] # Gives error
	
	
def mybuilder(target, source, env):
	env.Execute(Copy(target[0], source[0]))
	return None


env['BUILDERS']['MyBuilder'] = env.Builder(action=mybuilder, source_scanner=env.Scanner(function=myscanner))

out = env.MyBuilder('outfile1', 'infile1')

env.Install('#/install/dir1', out)
env.Install('#/install/dir2','infile2')


