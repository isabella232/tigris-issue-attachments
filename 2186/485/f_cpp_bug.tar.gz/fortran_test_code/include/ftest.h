character(len=64) :: test_char = "Hello, World!"
