public class Test
{
public static native void myfunc ();
}
