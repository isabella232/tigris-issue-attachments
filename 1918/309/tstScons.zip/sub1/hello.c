
/// main( ... ): program main function
int main( int iArgC, char *cpArgV[] )
{
    printf("hello");
}   