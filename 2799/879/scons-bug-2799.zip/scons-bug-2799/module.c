extern void bar(void)
{
}
