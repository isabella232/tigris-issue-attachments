#include "Precompiled.h"

int main()
{
    return testf();
}
