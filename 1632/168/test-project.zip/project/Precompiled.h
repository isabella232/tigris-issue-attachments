#pragma once

int testf()
{
    return 0;
}
