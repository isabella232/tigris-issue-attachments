cp mod.sh mod			# update target
echo >>hdr.h '/* modified */'	# modify header as well
