import SCons.Builder
import SCons.Node.FS
import SCons.Util
import os
import re
import sys
import string
import time

        
##########################################################################
#  Generate IDLTypeTable
#       IdlTypeTableMessage - custome message during generating (otherwise function name printed)
#       IdlTypeTableGenerate - 
#       _devPrintHeader - write top header message
#       _devAddHeaderFiles - add header files includes
#       _devAddIdcBody
#       _devAddImp - add imp header
#
#  Args: target - name of TypeTable file
#        source - list of idc files
def IdlTypeTableMessage(target, source, env):
    return 'Generating '+str(target[0])+'...'

def IdlTypeTableGenerate(target, source, env):
   
   fidl=file(str(target[0]), 'w',0)
   _devPrintHeader(fidl)
   _devGen(fidl,source[0].rfile().abspath)
   fidl.close()
   print 'Finish generating',str(target[0])
   return 0

def _devPrintHeader(fidl):
  header=['//============================================================================\n',
          '//\n',
          '// Warning: generated C++ code (DO NOT CHANGE!)\n',
          '//\n',
          '//============================================================================\n']
#  for x in range(1000):
  fidl.writelines(header)

      

def _devGen(fidl,itt):
   fitt=open(itt, 'r')
   fidl.write(fitt.read())
   fitt.close()
   
##########################################################################
#Set builders and general properties
#
def generate(env):
   env['NMX_IDL_ITT']='.itt'
   
   #register NmxIdlTypeTable builder
   Builder = SCons.Builder.Builder
   Action = SCons.Action.Action
   Scanner = SCons.Scanner.Scanner
   IdlTypeTableAction=Action(IdlTypeTableGenerate, strfunction=IdlTypeTableMessage)
   NmxIdlTypeTableBuilder= Builder(action=IdlTypeTableAction,
                                   src_suffix = '$NMX_IDL_ITT',
                                   suffix='$CXXFILESUFFIX')
   try:
      bld = env['BUILDERS']['NmxIdlTypeTable']
   except KeyError:
      bld = NmxIdlTypeTableBuilder
      env['BUILDERS']['NmxIdlTypeTable'] = bld
   
   static_obj, shared_obj = SCons.Tool.createObjBuilders(env)
   static_obj.src_builder.append('NmxIdlTypeTable')
   shared_obj.src_builder.append('NmxIdlTypeTable')
  
def exists(env):
   return 1
