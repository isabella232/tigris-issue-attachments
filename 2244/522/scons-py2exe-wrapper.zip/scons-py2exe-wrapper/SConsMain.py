# file: SConsMain.py
#

'''
bridge to SCons.Script.main()
used by py2exe
''' 

import os, sys, imp, atexit

# importing scons
import SCons
import SCons.Script

# run scons
SCons.Script.main()

# end of file