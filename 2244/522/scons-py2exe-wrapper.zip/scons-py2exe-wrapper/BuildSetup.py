# file: BuildSetup.py
#

''' 
uses py2exe and InnoSetup to package SCons in a self-contained windows application
'''

import sys, os, shutil, zipfile, time, stat, glob
import win32api
import subprocess, win32process
from distutils.core import setup
import py2exe

import SCons

print '*' * 40
print 'creating setup file for SCons'

# include/exclude packages
packages = []
includes = ["encodings.utf_8"]
excludes = ["pywin", "pywin.debugger", "pywin.debugger.dbgcon",
            "pywin.dialogs", "pywin.dialogs.list",
            "Tkconstants", "Tkinter", "tcl",
            "_imagingtk", "PIL._imagingtk", "ImageTk", "PIL.ImageTk", "FixTk"]

# include SCons Platform and Tool modules which are loaded at runtime
for directory in ['Platform', 'Tool']:
    for fname in glob.glob('SCons/%s/*.py' % directory):
        fname = (fname.replace('.py', '').
                 replace('/',   '.').
                 replace('\\',  '.'))
        print 'adding', fname
        includes.append(fname)

# build setup
print 'start building setup'
sys.argv += ['py2exe']
setup(
    options = {
        "py2exe": {
            "compressed":    9,
            "optimize":      2,
            "ascii":         1,
            "bundle_files":  1,
            "packages":      packages,
            "includes":      includes,
            "excludes":      excludes}},
    zipfile = 'library',
    console = [{'script' :          'SconsMain.py',
                'icon_resources' :  [(0, 'icons/scons.ico')]}])
print 'setup built'

# rename exe
print 'rename SConsMain.exe to SCons.exe'
try:     os.remove('dist/SCons.exe')
except:  pass
os.rename('dist/SConsMain.exe', 'dist/SCons.exe')

# insert the version into inno setup
print 'insert the version into inno setup'
setup_iss = os.path.abspath('./Setup.iss')
win32api.WriteProfileVal('Setup', 'AppVersion', SCons.__version__, setup_iss)
win32api.WriteProfileVal('Setup', 'AppVerName', 'SCons v %s' % SCons.__version__, setup_iss)
win32api.WriteProfileVal('Setup', 'VersionInfoVersion', SCons.__version__, setup_iss)

# run inno setup
print 'running inno setup compiler'
subprocess.call([r"C:\Programmi\Inno Setup 5\iscc.exe", 'setup.iss'])
print 'setup file is %d Kbytes' % (os.stat('setup.exe')[stat.ST_SIZE] / 1024)

print '*** DONE ***'


# end of file