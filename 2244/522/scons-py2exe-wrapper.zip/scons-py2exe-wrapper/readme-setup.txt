This is a wrapper for SCons, using py2exe and inno setup.
This wrapper allows SCons to be installed on a generic Windows PC without Python.
In order to build the setup.exe file:

- copy the SCons source tree in directory SCons
- copy the user manual pdf and man pages htmp to folder "doc"
- run "buildsetup.py"

fabio.parodi@technoleader.it