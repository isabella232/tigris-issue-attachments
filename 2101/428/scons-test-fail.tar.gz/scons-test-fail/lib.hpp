#ifndef _MY_LIB
#define _MY_LIB

extern int CheckFunc(int arg);

#endif
