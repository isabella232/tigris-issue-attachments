#include "lib.hpp"
#include <iostream>

int CheckFunc(int arg)
{
  std::cout<<"ARG "<<arg<<std::endl;
}
