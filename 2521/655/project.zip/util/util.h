#ifndef UTIL_H_
#define UTIL_H_

#include "calc/whatever.h"

#endif /* UTIL_H_ */