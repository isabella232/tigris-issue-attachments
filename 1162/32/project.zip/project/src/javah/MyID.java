import java.util.*;
import java.io.IOException;
import java.lang.reflect.*;

public class MyID 
{
	static private long current = System.currentTimeMillis();
	static public String get()
	{
		current++;
		return new Long( current ).toString();
	}
}
