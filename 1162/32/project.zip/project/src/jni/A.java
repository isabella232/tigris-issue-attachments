package web.jni;

import web.jni.*;

public class A
{
class C 
{
	void echo2( String text )
	{
		System.out.println( text+"aa" );
		
	}
}
class B 
{
	void echo( String text )
	{
		System.out.println( text );
		C c = new C();
		c.echo2("from B callin C");
	}
}
	public void main( String[] x)
	{
		B b = new B();
		b.echo("123");
		C c = new C();
		c.echo2("456");
	}
}
