#include <vector>
#include <iostream>

class SampleTest
{
public:
    std::vector<double> test1( std::pair<std::string, std::string> param )
    {
        std::vector<double> result;
        result.push_back(10);
        return result;
    }
};

