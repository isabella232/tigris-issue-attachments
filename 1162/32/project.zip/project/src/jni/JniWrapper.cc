#include <vector>
#include <iostream>

#include "JniWrapper.h"



JniWrapper::JniWrapper( JNIEnv *pEnv )
    : mpEnv( pEnv )
{
}

JniWrapper::JniWrapper( const JniWrapper& rJniWrapper )
    : mpEnv( rJniWrapper.mpEnv )
{
}

JniWrapper::~JniWrapper()
{

}

JniWrapper& JniWrapper::operator=( const JniWrapper& rJniWrapper )
{
    if ( this != &rJniWrapper )
    {
        mpEnv = rJniWrapper.mpEnv;
    }
    return *this;
}

std::string JniWrapper::unmarshalString( jstring value )
{
    std::string result;
    if( value )
    {
        const char *pStr = mpEnv->GetStringUTFChars( value, 0 );
        result = pStr;
        mpEnv->ReleaseStringUTFChars( value, pStr );
    }
    return result;
}

jobject JniWrapper::marshalDouble( double value )
{
    jclass classObject = mpEnv->FindClass( "java/lang/Double" );
    jmethodID constructorId = mpEnv->GetMethodID( classObject, "<init>", "(D)V" );
    jobject result = mpEnv->NewObject( classObject, constructorId, value );

    return result;
}

jobject JniWrapper::getVectorElement( jobject values, int i )
{
    jclass vectorClass = mpEnv->FindClass( "java/util/Vector" );
    jmethodID methodID = mpEnv->GetMethodID( vectorClass,
                                             "elementAt",
                                             "(I)Ljava/lang/Object;" );
    jobject result = mpEnv->CallObjectMethod( values, methodID, i );  

    return result;
}

jobject JniWrapper::newVector()
{
    jclass vectorClass = mpEnv->FindClass( "java/util/Vector" );
    jmethodID   constructorID = mpEnv->GetMethodID( vectorClass, "<init>", "()V" );
    jobject result = mpEnv->NewObject( vectorClass, constructorID );

    return result;
}

void JniWrapper::addElement( jobject vector, jobject element )
{
    jclass vectorClass = mpEnv->FindClass( "java/util/Vector" );
    jmethodID addElementMethodID = mpEnv->GetMethodID( vectorClass,
                                                       "addElement",
                                                       "(Ljava/lang/Object;)V" );

    mpEnv->CallVoidMethod( vector, addElementMethodID, element );
}

jobject JniWrapper::marshalDoubleVector( const std::vector<double>& rVector )
{
    jobject result = newVector();
  
    for ( int i = 0; i < rVector.size(); i++ )
    {         
          addElement( result, marshalDouble( rVector[i] ) );
    }

    return result;
}

std::pair<std::string, std::string> JniWrapper::unmarshalPairString( jobject vector )
{
    std::pair<std::string, std::string> result;
    result.first  = unmarshalString( (jstring)getVectorElement( vector, 0 ) );
    result.second = unmarshalString( (jstring)getVectorElement( vector, 1 ) );
    
    return result;
}
