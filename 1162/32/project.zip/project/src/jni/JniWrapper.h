#ifndef JniWrapper_h
#define JniWrapper_h

#include <jni.h>
/**      
 * Provides routines for dealing with JNI translation etc.
 */

class JniWrapper
{
public:
    JniWrapper( JNIEnv *pEnv );
    JniWrapper( const JniWrapper& rJniWrapper );
    virtual ~JniWrapper();
    JniWrapper& operator=( const JniWrapper& rJniWrapper );


    std::string unmarshalString( jstring value );

    jstring marshalString( const std::string& value );

    jbyteArray marshalByteArray( const std::string& value );

    double unmarshalDouble( jobject value );

    jobject marshalDouble( double value );
    jobject marshallStringVector( const std::vector<std::string>& rMap );

    jobject marshalDoubleVector( const std::vector<double>& rVector );
    std::pair<std::string, std::string> unmarshalPairString( jobject );

protected:
    JNIEnv *mpEnv;

private:
    JniWrapper();
    jobject newVector();
    void addElement( jobject vector, jobject element );
    jobject getVectorElement( jobject values, int i );

};

#endif // JniWrapper_h


