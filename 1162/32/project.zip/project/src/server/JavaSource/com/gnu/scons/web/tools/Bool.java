package com.gnu.scons.web.tools;
public class Bool {
	boolean flag;
	
	public Bool()
	{
		flag = false;
	}
	
	public Bool( boolean aFlag )
	{
		flag = aFlag;
	}
	
	public boolean booleanValue()
	{
		return flag;
	}
}
