package com.gnu.scons.web.tools;

import java.util.Iterator;
import java.util.Map;

public class StringUtils 
{
	public static String toPercent( String value )
	{
		if ( value.equals("") )
		{
			return "";
		}
		else
		{
			return value + "%";
		}
	}
	
}
