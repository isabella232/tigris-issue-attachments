package com.Hello;
import java.awt.*;
import java.applet.*;

public class Hello extends Applet {
    public void paint(Graphics g) {
	g.drawString("Hello from SCons signed applet",250,150);
	}
    }

