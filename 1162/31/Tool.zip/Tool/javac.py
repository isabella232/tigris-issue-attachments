"""SCons.Tool.javac

Tool-specific initialization for javac.

There normally shouldn't be any need to import this module directly.
It will usually be imported through the generic SCons.Tool.Tool()
selection method.

"""

#
# Copyright (c) 2001, 2002, 2003, 2004 The SCons Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

__revision__ = "src\engine\SCons\Tool\javac.py 0.96 2005/05/10 11:17:20 ln7213181"

import os
import os.path
import string
import fnmatch

import SCons.Action
import SCons.Builder
import SCons.Tool
from SCons.Node.FS import _my_normcase,Dir,File
from SCons.Tool.JavaCommon import parse_java_file
import SCons.Util

def classname(path):
    """Turn a string (path name) into a Java class name."""
    return string.replace(os.path.normpath(path), os.sep, '.')

def emit_java_classes(target, source, env):
    """Create and return lists of source java files
    and their corresponding target class files.
    """

    java_suffix = env.get('JAVASUFFIX', '.java')
    class_suffix = env.get('JAVACLASSSUFFIX', '.class')
    js = _my_normcase(java_suffix)
    scandir=False
    #There is a bug here fo rFile input if BuildDir set, but does not exist
    #target[0].dir is '.', but target[0].dir.rdir() is pointing to src dir, not build_dir
    #So I am trying to fix it here
    
    if isinstance(source[0],File):
       build_dir=os.path.split(target[0].get_abspath())[0]
       if os.path.basename(str(source[0])) == str(source[0]):
          src_dir=build_dir
       else:
          src_dir=os.path.split(str(source[0]))[0]
    elif isinstance(source[0],Dir):
       build_dir=target[0].rdir().get_abspath()
       src_dir=source[0].rdir().get_abspath()
    else:
       raise SCons.Errors.UserError('Java source should be File or Dir')
    tlist = []    
    slist = []    

    for file_or_dir in source:
       if isinstance(file_or_dir,File):
          scandir=False
       elif isinstance(file_or_dir,Dir):
          scandir=True
       else:
          raise SCons.Errors.UserError('Java source should be File or Dir')
       if scandir:    
          def visit(arg, dirname, names, js=js, dirnode=file_or_dir.rdir()):
            java_files = filter(lambda n, js=js:
                                   _my_normcase(n[-len(js):]) == js,
                                   names)
            mydir = dirnode.Dir(dirname)
            dirnamelist=dirname.split(os.sep)
            if 'CVS' not in  dirnamelist:
               java_paths = map(lambda f, d=mydir: d.File(f), java_files)
               arg.extend(java_paths)
          os.path.walk(file_or_dir.rdir().get_abspath(), visit, slist)
       else:
          slist.append(file_or_dir)
          
    for f in slist:
        #Problem: File might be derived and does not exist at this moment
        #Do not scan such files. So we might miss internal classes.
        #Just make sure that generated .java file do not have internal classes
        #For example SWIG generates one .java per class, so it works
        source_file_based=True
        pkg_dir=None
        if not f.is_derived():
           pkg_dir, classes = parse_java_file(str(f))
#           print 'For java:',str(f),' dir: ',pkg_dir,' classes: ',classes
           if pkg_dir:        
               for c in classes:
                   source_file_based=False
                   t = target[0].Dir(pkg_dir).File(c+class_suffix)
                   t.attributes.java_classdir = build_dir
                   t.attributes.java_sourcedir = src_dir
                   t.attributes.java_classname = classname(pkg_dir + os.sep + c)
                   tlist.append(t)
           elif classes:
               for c in classes:
                   source_file_based=False
                   t = target[0].File(c+class_suffix)
                   t.attributes.java_classdir = build_dir
                   t.attributes.java_sourcedir = src_dir
                   t.attributes.java_classname = classname(c)
                   tlist.append(t)

        if source_file_based:
            # generate .class name based on .java file name.
            #for derived and .java file without classes
            base = os.path.basename(str(f))[:-len(java_suffix)]
            if pkg_dir:
               t = target[0].Dir(pkg_dir).File(base + class_suffix)
            else:
               t = target[0].File(base + class_suffix)
            t.attributes.java_classdir = build_dir
            t.attributes.java_sourcedir = src_dir
            t.attributes.java_classname = classname(base)
            tlist.append(t)
#    print "Emit for: " + str(source[0]) + " => " + str(map(lambda x: str(x.get_abspath()),list(tlist)))
    return tlist, slist
    
def getClassPath(env,target, source, for_signature):
   path = ""
   if env.has_key('JAVACLASSPATH') and env['JAVACLASSPATH']:
      path=SCons.Util.AppendPath(path,env['JAVACLASSPATH'])
      return "-classpath %s"%(path)
   else:
      return ""

def getSourcePath(env,target, source, for_signature):
   path = ""
   if env.has_key('JAVASOURCEPATH') and env['JAVASOURCEPATH']:
      path=SCons.Util.AppendPath(path,env['JAVASOURCEPATH'])
   path=SCons.Util.AppendPath(path,['${TARGET.attributes.java_classdir}','${TARGET.attributes.java_sourcedir}'])
   return "-sourcepath %s"%(path)

def generate(env):
   java_file=SCons.Tool.CreateJavaFileBuilder(env)
   java_class=SCons.Tool.CreateJavaClassBuilder(env)
   java_class_dir=SCons.Tool.CreateJavaClassDirBuilder(env)
   java_class.add_emitter('$JAVASUFFIX', emit_java_classes)
   java_class_dir.emitter=emit_java_classes
   env['JAVAC']            = 'javac'
   env['JAVACFLAGS']       = SCons.Util.CLVar('')
   env['JAVACLASSSUFFIX']  = '.class'
   env['JAVASUFFIX']       = '.java'
   env['JAVACLASSPATH']=[]
   env['JAVASOURCEPATH']=[]
   env['_JAVACLASSPATH']=getClassPath
   env['_JAVASOURCEPATH']=getSourcePath
   env['_JAVACOM']='$JAVAC $JAVACFLAGS $_JAVACLASSPATH -d ${TARGET.attributes.java_classdir} $_JAVASOURCEPATH $SOURCES'
   env['JAVACOM']="${TEMPFILE('$_JAVACOM')}"
   
def exists(env):
   return 1
