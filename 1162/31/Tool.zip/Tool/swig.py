"""SCons.Tool.swig

Tool-specific initialization for swig.

There normally shouldn't be any need to import this module directly.
It will usually be imported through the generic SCons.Tool.Tool()
selection method.

"""

#
# Copyright (c) 2001, 2002, 2003, 2004 The SCons Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

__revision__ = "/home/scons/scons/branch.0/baseline/src/engine/SCons/Tool/swig.py 0.96.1.D001 2004/08/23 09:55:29 knight"

import SCons.Defaults
import SCons.Tool
import SCons.Util
import re
adjustixes = SCons.Util.adjustixes

def _parseForJava(node, env):
   includes_reg = re.compile('^[ \t]*//[ \t]*generate[ \t]*:(.*)',re.M)
   return includes_reg.findall(node.get_contents())

def swigSuffixEmitter(env, source):
    if '-c++' in SCons.Util.CLVar(env.subst("$SWIGFLAGS")):
        return '$SWIGCXXFILESUFFIX'
    else:
        return '$SWIGCFILESUFFIX'
   
def swigEmitter(target, source, env):
   bs = SCons.Util.splitext(str(source[0].name))[0]
   target[0].name=adjustixes(bs, None, env.subst(swigSuffixEmitter(env, source)))
   #Scan for java targets
   if '-java' in SCons.Util.CLVar(env.subst("$SWIGFLAGS")):
      target.extend(_parseForJava(source[0],env))
      
#   print "Targets for: " + str(source[0].name) + " => " + str(map(lambda x: str(x),list(target))) 
   return target, source

SwigBuilder = SCons.Builder.Builder(action = '$SWIGCOM',
                      			     emitter = swigEmitter,
                                   source_scanner=SCons.Defaults.CScan,
                      			     src_suffix = '$SWIGINTERFACEUFFIX',
                                   suffix=swigSuffixEmitter)
def generate(env):

   try:
      bld = env['BUILDERS']['Swig']
   except KeyError:
      bld = SwigBuilder
      env['BUILDERS']['Swig'] = bld
   static_obj, shared_obj = SCons.Tool.createObjBuilders(env)
   static_obj.src_builder.append('Swig')
   shared_obj.src_builder.append('Swig')
   java_class = SCons.Tool.CreateJavaClassBuilder(env)
   java_class.src_builder.append('Swig')
   
   env['SWIG']              = 'swig'
   env['SWIGFLAGS']         = SCons.Util.CLVar('')
   env['SWIGINTERFACEUFFIX']   = '.i'
   env['SWIGCFILESUFFIX']   = '_wrap$CFILESUFFIX'
   env['SWIGCXXFILESUFFIX'] = '_wrap$CXXFILESUFFIX'
   env['SWIGCOM']           = '$SWIG $SWIGFLAGS -o $TARGET $SOURCES'

def exists(env):
   return env.Detect('swig')
