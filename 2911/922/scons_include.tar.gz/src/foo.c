
#include <stdio.h>
#include "foo.h"

int main (int argc, char* argv) {
	
	printf("foo: %d\n",FOO);
	return 0;
}
