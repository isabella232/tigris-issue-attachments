#include "hello.h"

int main(void) {
  do_hello();
  return 0;
}
