/* This is public header for the extensive Hello, World module */

#ifndef HELLO_H
#define HELLO_H

void do_hello(void);

#endif
