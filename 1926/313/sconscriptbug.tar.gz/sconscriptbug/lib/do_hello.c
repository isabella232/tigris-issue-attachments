#include <stdio.h>

void do_hello(void) {
  printf("Hello world\n");
}
