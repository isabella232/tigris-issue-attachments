#include "utils/a.hpp"
#include "main.hpp"

int
main(int argc, char *argv[])
{
    A<int> a;

    return 0;
}
