template <class T>
struct A {
    T a;
};
