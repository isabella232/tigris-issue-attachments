struct B {
    int x;
};
