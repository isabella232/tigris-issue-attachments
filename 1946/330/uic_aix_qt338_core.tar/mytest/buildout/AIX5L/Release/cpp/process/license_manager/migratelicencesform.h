/****************************************************************************
** Form interface generated from reading ui file 'src/cpp/process/license_manager/migratelicencesform.ui'
**
** Created: Fri Mar 14 10:49:17 2008
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.8   edited Jan 11 14:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef MIGRATELICENCESFORM_H
#define MIGRATELICENCESFORM_H

#include <qvariant.h>
#include <qwizard.h>
#include "ConfigurationFile.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QWidget;
class QLineEdit;
class QPushButton;
class QLabel;
class QListView;
class QListViewItem;

class MigrateLicencesForm : public QWizard
{
    Q_OBJECT

public:
    MigrateLicencesForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MigrateLicencesForm();

    QWidget* WizardPage;
    QLineEdit* lineEdit2;
    QPushButton* browseButton;
    QLabel* textLabelPageOne;
    QWidget* WizardPage_2;
    QListView* migrateLicenceList;
    QLabel* textLabelPageTwo;

    virtual void init();
    void setConfigurationFile( ConfigurationFile * pFile );

public slots:
    virtual void selectionChanged();
    virtual void browse();

protected:

protected slots:
    virtual void languageChange();

    virtual void next();
    virtual void accept();


private:
    ConfigurationFile* _config;
    std::string _originalLicenceRoot;

    bool setLicenceDirectory();
    void clearAndPopulateList();

};

#endif // MIGRATELICENCESFORM_H
