/****************************************************************************
** Form implementation generated from reading ui file 'src/cpp/process/license_manager/migratelicencesform.ui'
**
** Created: Fri Mar 14 06:51:28 2008
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.8   edited Jan 11 14:47 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "migratelicencesform.h"

#include <qvariant.h>
#include <dev_utils/scpf_first.h>
#include <dev_utils/stl_core.h>
#include <dev_utils/scpf_core.h>
#include <qapplication.h>
#include <qmessagebox.h>
#include <dev_utils/Directory.h>
#include <qlistview.h>
#include <qwidget.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qheader.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "LicenceSystem.h"
#include "LicenceListItem.h"
#include "SelectLicenceRootDialog.h"
/*
 *  Constructs a MigrateLicencesForm as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The wizard will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal wizard.
 */
MigrateLicencesForm::MigrateLicencesForm( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QWizard( parent, name, modal, fl )
{
    if ( !name )
	setName( "MigrateLicencesForm" );

    WizardPage = new QWidget( this, "WizardPage" );

    lineEdit2 = new QLineEdit( WizardPage, "lineEdit2" );
    lineEdit2->setGeometry( QRect( 0, 40, 470, 30 ) );
    lineEdit2->setFrameShape( QLineEdit::LineEditPanel );
    lineEdit2->setFrameShadow( QLineEdit::Sunken );

    browseButton = new QPushButton( WizardPage, "browseButton" );
    browseButton->setGeometry( QRect( 480, 40, 101, 30 ) );

    textLabelPageOne = new QLabel( WizardPage, "textLabelPageOne" );
    textLabelPageOne->setGeometry( QRect( 0, 0, 580, 40 ) );
    addPage( WizardPage, QString("") );

    WizardPage_2 = new QWidget( this, "WizardPage_2" );

    migrateLicenceList = new QListView( WizardPage_2, "migrateLicenceList" );
    migrateLicenceList->addColumn( tr( "Product" ) );
    migrateLicenceList->addColumn( tr( "# Users" ) );
    migrateLicenceList->addColumn( tr( "Expiry Date" ) );
    migrateLicenceList->setGeometry( QRect( 0, 40, 590, 260 ) );
    migrateLicenceList->setSelectionMode( QListView::Extended );
    migrateLicenceList->setAllColumnsShowFocus( TRUE );
    migrateLicenceList->setItemMargin( 2 );
    migrateLicenceList->setRootIsDecorated( TRUE );
    migrateLicenceList->setResizeMode( QListView::LastColumn );

    textLabelPageTwo = new QLabel( WizardPage_2, "textLabelPageTwo" );
    textLabelPageTwo->setGeometry( QRect( 4, -2, 580, 40 ) );
    textLabelPageTwo->setAlignment( int( QLabel::WordBreak | QLabel::AlignVCenter ) );
    addPage( WizardPage_2, QString("") );
    languageChange();
    resize( QSize(600, 385).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( browseButton, SIGNAL( clicked() ), this, SLOT( browse() ) );
    connect( migrateLicenceList, SIGNAL( selectionChanged() ), this, SLOT( selectionChanged() ) );
    init();
}

/*
 *  Destroys the object and frees any allocated resources
 */
MigrateLicencesForm::~MigrateLicencesForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void MigrateLicencesForm::languageChange()
{
    setCaption( tr( "Migrate Licenses" ) );
    browseButton->setText( tr( "Browse" ) );
    textLabelPageOne->setText( tr( "Licenses will be moved into %1.\n"
"Please enter the source license directory:" ) );
    setTitle( WizardPage, tr( "Source Directory" ) );
    migrateLicenceList->header()->setLabel( 0, tr( "Product" ) );
    migrateLicenceList->header()->setLabel( 1, tr( "# Users" ) );
    migrateLicenceList->header()->setLabel( 2, tr( "Expiry Date" ) );
    textLabelPageTwo->setText( tr( "Please select the licenses to migrate.  Expired and invalid licenses are not shown." ) );
    setTitle( WizardPage_2, tr( "Select Licenses" ) );
}

void MigrateLicencesForm::next()
{
    qWarning( "MigrateLicencesForm::next(): Not implemented yet" );
}

void MigrateLicencesForm::accept()
{
    qWarning( "MigrateLicencesForm::accept(): Not implemented yet" );
}

void MigrateLicencesForm::selectionChanged()
{
    qWarning( "MigrateLicencesForm::selectionChanged(): Not implemented yet" );
}

void MigrateLicencesForm::browse()
{
    qWarning( "MigrateLicencesForm::browse(): Not implemented yet" );
}

void MigrateLicencesForm::init()
{
}

void MigrateLicencesForm::setConfigurationFile(ConfigurationFile*)
{
    qWarning( "MigrateLicencesForm::setConfigurationFile(ConfigurationFile*): Not implemented yet" );
}

bool MigrateLicencesForm::setLicenceDirectory()
{
    qWarning( "MigrateLicencesForm::setLicenceDirectory(): Not implemented yet" );
    return FALSE;
}

void MigrateLicencesForm::clearAndPopulateList()
{
    qWarning( "MigrateLicencesForm::clearAndPopulateList(): Not implemented yet" );
}

