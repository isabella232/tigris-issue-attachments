/****************************************************************************
** MigrateLicencesForm meta object code from reading C++ file 'migratelicencesform.h'
**
** Created: Fri Mar 14 06:51:29 2008
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.8   edited Feb 2 14:59 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "migratelicencesform.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *MigrateLicencesForm::className() const
{
    return "MigrateLicencesForm";
}

QMetaObject *MigrateLicencesForm::metaObj = 0;
static QMetaObjectCleanUp cleanUp_MigrateLicencesForm( "MigrateLicencesForm", &MigrateLicencesForm::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString MigrateLicencesForm::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MigrateLicencesForm", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString MigrateLicencesForm::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MigrateLicencesForm", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* MigrateLicencesForm::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWizard::staticMetaObject();
    static const QUMethod slot_0 = {"selectionChanged", 0, 0 };
    static const QUMethod slot_1 = {"browse", 0, 0 };
    static const QUMethod slot_2 = {"languageChange", 0, 0 };
    static const QUMethod slot_3 = {"next", 0, 0 };
    static const QUMethod slot_4 = {"accept", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "selectionChanged()", &slot_0, QMetaData::Public },
	{ "browse()", &slot_1, QMetaData::Public },
	{ "languageChange()", &slot_2, QMetaData::Protected },
	{ "next()", &slot_3, QMetaData::Protected },
	{ "accept()", &slot_4, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"MigrateLicencesForm", parentObject,
	slot_tbl, 5,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_MigrateLicencesForm.setMetaObject( metaObj );
    return metaObj;
}

void* MigrateLicencesForm::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "MigrateLicencesForm" ) )
	return this;
    return QWizard::qt_cast( clname );
}

bool MigrateLicencesForm::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: selectionChanged(); break;
    case 1: browse(); break;
    case 2: languageChange(); break;
    case 3: next(); break;
    case 4: accept(); break;
    default:
	return QWizard::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool MigrateLicencesForm::qt_emit( int _id, QUObject* _o )
{
    return QWizard::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool MigrateLicencesForm::qt_property( int id, int f, QVariant* v)
{
    return QWizard::qt_property( id, f, v);
}

bool MigrateLicencesForm::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
