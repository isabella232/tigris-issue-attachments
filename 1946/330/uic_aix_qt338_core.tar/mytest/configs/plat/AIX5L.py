#self['LINKFLAGS']=['-bnoautoexp','-brtl','-bgc','-bloadmap:$LOADMAP','-bh:5']
