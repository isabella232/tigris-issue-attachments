#self.AppendUnique(CPPDEFINES = ['NMX_DEBUG'])
