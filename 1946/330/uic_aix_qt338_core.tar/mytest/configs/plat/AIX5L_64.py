#self.AppendUnique(CPPDEFINES=['UNIX_64'])

#self.AppendUnique(LINKFLAGS=['-qtwolink'])
#self.AppendUnique(CCFLAGS=['-qmaxmem=-1'])
#self['ENV']['LDR_CNTRL']='MAXDATA=0x80000000'
