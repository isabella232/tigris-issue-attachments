#self.Append(CPPDEFINES = 'SCONS')
self['PRODUCT_NAME']='Supply Chain Planning Foundation'  
