int someFunc() {
    return 0;
}