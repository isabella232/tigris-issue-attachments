int someFunc() {
    return gibberish;
}