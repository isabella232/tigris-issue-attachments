#include "foo.h"

int main() {
    int someValue = someFunc();
    
    return 0;
}