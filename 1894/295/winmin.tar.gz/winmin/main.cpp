#include <windows.h>

#define WNDCLASSNAME TEXT("WinMin")
#define WNDCAPTION TEXT("WinMin")

static bool g_bRunning = true;

LRESULT WINAPI WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam){
	switch(Msg){
		case (WM_DESTROY):{
			g_bRunning = false;
			PostQuitMessage(0);
			return 0;
		}
        default:
            return DefWindowProc(hWnd, Msg, wParam, lParam);
	}
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int){
    WNDCLASS wc = {
        CS_VREDRAW|CS_HREDRAW,
        WndProc, 0, 0,
        hInst,
        LoadIcon(0, IDI_APPLICATION),
        LoadCursor(0, IDC_ARROW),
        (HBRUSH)GetStockObject(LTGRAY_BRUSH),
        0,
        WNDCLASSNAME
    };

    RegisterClass(&wc);

    HWND hWnd = 
    CreateWindow(
                                WNDCLASSNAME,
                                WNDCAPTION, 
                                WS_OVERLAPPEDWINDOW,
                                CW_USEDEFAULT,
                                CW_USEDEFAULT,
                                CW_USEDEFAULT,
                                CW_USEDEFAULT,
                                0, 0, hInst, 0
                                );
    UpdateWindow(hWnd);
    ShowWindow(hWnd, SW_SHOW);

    MSG msg;
    while (g_bRunning){
        if (PeekMessage(&msg, hWnd, 0, 0, PM_REMOVE)){
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else{
            //idle
        }
    }

    UnregisterClass(WNDCLASSNAME, hInst);

    return 0;
}