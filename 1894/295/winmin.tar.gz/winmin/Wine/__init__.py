import mslib
import mslink
import msvc

def generate(env):
    mslib.generate(env)
    mslink.generate(env)
    msvc.generate(env)
