"""SCons.Tool.tar

Tool-specific initialization for tar.

There normally shouldn't be any need to import this module directly.
It will usually be imported through the generic SCons.Tool.Tool()
selection method.

"""
# __COPYRIGHT__
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

__revision__ = "__FILE__ __REVISION__ __DATE__ __DEVELOPER__"

try:
	import SCons, tarfile, os
	from Node import NodeWrapper
except ImportError:
	def exists(env): return 0
else:
	def exists(env): return 1

class TarWrap(NodeWrapper):
	def __init__(self, name, kw):
		name,nym = name
		String = SCons.Util.is_String
		if not String(nym):
			raise SCons.Error.UserError(
				"Archive name for '%s' must be a string" % str(name))

		# if the name is a string, convert it into an Entry
		if String(name):
			if 'srcdir' in kw and not os.path.isabs(name):
				name = os.path.join(kw['srcdir'], name)
			name = Entry(name)
		if not nym: nym = str(name)
		self.nym = nym
		NodeWrapper.__init__(self, name)
	def __str__(self):
		return str(self.node) + ' --> ' + self.nym

def TarFunction(source, target, env):
	for t in target:
		umask = os.umask(0)
		os.umask(umask|0111)
		flags = env['TARFLAGS']
		print 'Creating tar', flags, t, '...'
		if '-z' in flags:
			mode = 'w|gz'
		elif '-j' in flags:
			mode = 'w|bz2'
		else:
			mode = 'w|'
		tar = tarfile.open(str(t), mode)
		for s in source:
			if isinstance(s, TarWrap):
				print '... source', str(s.node), '-->', s.nym
				tar.add(str(s.node), s.nym, recursive = True)
			else:
				print '... source', str(s)
				tar.add(str(s), recursive = True)
		tar.close()
		os.umask(umask)

TarAction = SCons.Action.Action(TarFunction, '<<tar>> $TARFLAGS -f $TARGET ...')

TarBuilder = SCons.Builder.Builder(action = TarAction,
                                   source_factory = SCons.Node.FS.Entry,
                                   source_scanner = SCons.Defaults.DirScanner,
                                   suffix = '$TARSUFFIX',
                                   multi = 1)

def Tarfile(self, target = None, source = None, **kw):
	if source is not None:
		Tuple = SCons.Util.is_Tuple
		s = []
		for t in source:
			if Tuple(t) and len(t) == 2:
				s.append(TarWrap(t, kw))
			else:
				s.append(t)
	return TarBuilder(self, target, s, **kw)

def generate(env):
	"""Add Builders and construction variables for tar to an Environment."""
	#env['TAR']        = env.Detect('tar') or 'gtar'
	env['TARFLAGS']   = SCons.Util.CLVar('-c')
	#env['TARCOM']     = '$TAR $TARFLAGS -f $TARGET $SOURCES'
	#env['TARCOMSTR']  = '$TAR $TARFLAGS -f $TARGET ...'
	env['TARSUFFIX']  = '.tar'

	try:
		env['BUILDERS']['Tar']
	except KeyError:
		env['BUILDERS']['Tar'] = Tarfile
