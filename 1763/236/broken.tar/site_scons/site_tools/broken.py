cplusplus = __import__('g++', globals(), locals(), [])
