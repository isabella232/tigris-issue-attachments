#include <stdio.h>

int hello(void)
{
	return printf("Orbis, te saluto!\n");
}

int humbug(void)
{
	return printf("Go away!\n");
}
