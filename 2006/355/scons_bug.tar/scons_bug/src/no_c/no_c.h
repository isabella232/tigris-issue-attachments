#define FOO "foo"
