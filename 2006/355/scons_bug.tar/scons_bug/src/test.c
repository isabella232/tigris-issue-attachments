#include <stdio.h>
#include "no_c/no_c.h"

int main() {
	printf(FOO);
	return 0;
}

