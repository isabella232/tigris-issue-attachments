#ifndef MYHEADER_HPP
#define MYHEADER_HPP

void myfunc();
void yourfunc();

#endif
