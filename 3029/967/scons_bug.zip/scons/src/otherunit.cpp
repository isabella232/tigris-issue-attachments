
int otherfunc()
{
	const int i = 50 + 100;

	return i / 4;
}

