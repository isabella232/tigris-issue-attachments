package mypackage;

public class Junk
{
	public void blah() throws Exception
	{
		throw new Exception("");
	}
}

