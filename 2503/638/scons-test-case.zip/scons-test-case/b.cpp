int bogus_function_2(void)
{
  return 2;
}
