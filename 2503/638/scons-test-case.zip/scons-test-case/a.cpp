int bogus_function_1(void)
{
  return 1;
}
