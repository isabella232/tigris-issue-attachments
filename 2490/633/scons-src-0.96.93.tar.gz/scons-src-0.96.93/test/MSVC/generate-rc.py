#!/usr/bin/env python
#
# Copyright (c) 2001, 2002, 2003, 2004 The SCons Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

__revision__ = "/home/scons/scons/branch.0/branch.96/baseline/test/MSVC/generate-rc.py 0.96.93.D001 2006/11/06 08:31:54 knight"

"""
Test adding a src_builder to the RES builder so that RC files can
be generated.
"""

import TestSCons

_python_ = TestSCons._python_

test = TestSCons.TestSCons()

fake_rc = test.workpath('fake_rc.py')

test.write(fake_rc, """\
import sys
contents = open(sys.argv[2], 'rb').read()
open(sys.argv[1], 'wb').write("fake_rc.py\\n" + contents)
""")

test.write('SConstruct', """
def generate_rc(target, source, env):
    t = str(target[0])
    s = str(source[0])
    tfp = open(t, 'wb')
    tfp.write('generate_rc\\n' + open(s, 'r').read())

env = Environment(tools=['msvc'],
                  RCCOM=r'%(_python_)s %(fake_rc)s $TARGET $SOURCE')
env['BUILDERS']['GenerateRC'] = Builder(action=generate_rc,
                                        suffix='.rc',
                                        src_suffix='.in')
env['BUILDERS']['RES'].src_builder.append('GenerateRC')

env.RES('my.in')
""" % locals())

test.write('my.in', "my.in\n")

test.run(arguments = '.')

test.must_match('my.rc', "generate_rc\nmy.in\n")
test.must_match('my.res', "fake_rc.py\ngenerate_rc\nmy.in\n")

test.pass_test()
