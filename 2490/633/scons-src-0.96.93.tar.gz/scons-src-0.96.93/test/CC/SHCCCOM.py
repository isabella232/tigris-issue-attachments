#!/usr/bin/env python
#
# Copyright (c) 2001, 2002, 2003, 2004 The SCons Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#

__revision__ = "/home/scons/scons/branch.0/branch.96/baseline/test/CC/SHCCCOM.py 0.96.93.D001 2006/11/06 08:31:54 knight"

import os
import string
import sys
import TestSCons

"""
Test the ability to configure the $SHCCCOM construction variable.
"""

_python_ = TestSCons._python_

test = TestSCons.TestSCons()



test.write('mycc.py', r"""
import sys
outfile = open(sys.argv[1], 'wb')
infile = open(sys.argv[2], 'rb')
for l in filter(lambda l: l[:6] != '/*cc*/', infile.readlines()):
    outfile.write(l)
sys.exit(0)
""")

if os.path.normcase('.c') == os.path.normcase('.C'):
    alt_c_suffix = '.C'
else:
    alt_c_suffix = '.c'

test.write('SConstruct', """
env = Environment(SHCCCOM = r'%(_python_)s mycc.py $TARGET $SOURCE',
                  SHOBJSUFFIX='.obj')
env.SharedObject(target = 'test1', source = 'test1.c')
env.SharedObject(target = 'test2', source = 'test2%(alt_c_suffix)s')
""" % locals())

test.write('test1.c', """\
test1.c
/*cc*/
""")

test.write('test2'+alt_c_suffix, """\
test2.C
/*cc*/
""")

test.run()

test.must_match('test1.obj', "test1.c\n")
test.must_match('test2.obj', "test2.C\n")



test.pass_test()
